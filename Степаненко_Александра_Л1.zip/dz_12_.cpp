﻿#include <iostream>
using namespace std;
int main()
{
    string a;
    cin >> a;
    cout << "Hello, " << a << "! My name is C++";
}