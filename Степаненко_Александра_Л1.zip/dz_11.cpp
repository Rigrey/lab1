﻿#include <iostream>
using namespace std;
int main()
{
    float r,d;
    cin >> r;
    d = r*2;
    cout << d;
}