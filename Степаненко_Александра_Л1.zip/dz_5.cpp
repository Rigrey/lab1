﻿#include <iostream>
using namespace std;
int main()
{
    float m,v;
    cin >> m >> v;
    cout << m/v
}