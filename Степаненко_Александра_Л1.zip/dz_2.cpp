﻿#include <iostream>
using namespace std;
int main()
{
    int a, b;
    cin >> a >> b;
    cout << '1' << a << "13"<< b << "49";
}