﻿#include <iostream>
using namespace std;
int main()
{
    float a,v,s;
    cin >> a;
    v = pow(a,3);
    s = 4 * pow(a, 2);
    cout << v << ' ' << s;
}