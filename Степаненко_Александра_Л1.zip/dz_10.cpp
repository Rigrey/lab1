﻿#include <iostream>
using namespace std;
int main()
{
    float a,s;
    cin >> a;
    s = pow(a,2);
    cout << s;
}