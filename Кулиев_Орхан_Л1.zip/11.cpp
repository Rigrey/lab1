﻿#include <iostream>
using namespace std;
int main()
{
    float r, d;
    cin >> r;
    d = 2 * r;
    cout << d;
}
