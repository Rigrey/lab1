﻿#include <iostream>
using namespace std;
int main()
{
    float p, m, v;
    cin >> v >> m;
    p = m / v;
    cout << p;
}
