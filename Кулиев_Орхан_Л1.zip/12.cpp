﻿#include <iostream>
#include <string>
using namespace std;

int main() {
    setlocale(LC_ALL, "RU");
    string name;
    cin >> name;
    cout << "Hello, " << name << "! My name is C++";
}