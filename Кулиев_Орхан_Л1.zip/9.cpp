﻿#include <iostream>
using namespace std;
int main()
{
    setlocale(LC_ALL, "RU");
    float a, v, s;
    cin >> a;
    s = 4 * pow(a, 2);
    v = pow(a, 3);
    cout << "объём-" << v << endl << "площадь боковой-" << s;
}
