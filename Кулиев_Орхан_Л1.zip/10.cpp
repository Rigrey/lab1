﻿#include <iostream>
using namespace std;
int main()
{
    int a, p;
    cin >> a;
    p = 4 * a;
    cout << p;
}
