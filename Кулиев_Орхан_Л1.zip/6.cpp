﻿#include <iostream>
using namespace std;
int main()
{
    float a, b, x;
    cin >> a >> b;
    x = -b / a;
    cout << x;
}
