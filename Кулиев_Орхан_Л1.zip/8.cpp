﻿#include <iostream>
using namespace std;
int main()
{
    float a, b, h, d, c,p;
    cin >> a >> b >> h;
    d = pow(((b - a) / 2), 2) + pow(h, 2);
    c = d;
    p = d + c + a + b;
    cout << p;
}
