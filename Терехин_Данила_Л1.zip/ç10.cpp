#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float b;
    //сторона квадрата
    cin >> b;
    cout << "Perimetr kvadrata raven: " << 4 * a << endl;

}
