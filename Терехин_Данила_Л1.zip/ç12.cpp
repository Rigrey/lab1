#include <iostream>
#include <string>

using namespace std;

int main(){
string name;
//имя студента
cin >> name;
cout << "Hello, " << name << "! " << "My name is C++" << endl;



}

