#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    float x1, x2, y1, y2, r;
    //1 коорд
    cin >> x1 >> y1;
    //2 коорд
    cin >> x2 >> y2;
    r = sqrt (pow(y1 - y2, 2) + pow(x1 - x2, 2));
    //расстояние
    cout << r;
    return 0;
}
