#include <iostream>
#include <cmath>

using namespace std;

int main(){
float b, v;
//объем и масса
cin >> v >> b;
cout << "Plotnost tela " << b / v<< endl;

}

