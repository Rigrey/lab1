#include <iostream>
#include <cmath>

using namespace std;

int main(){
float a, b;
//a и b не равное нулю
cin >> a >> b;
cout << "Reshenie uravneniya: " << -1 * (b / a) << endl;

}

