#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float r;
    //радиус окружности
    cin >> r;
    cout << "Diametr okruzhnosti raven: " << 2 * r << endl;
}
