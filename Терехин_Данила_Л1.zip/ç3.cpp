#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int a, b, c;
    //1 число
    cin >> a;
    //2 число
    cin >> b;
    //3 число
    cin >> c;
    cout << a << "  " << b << "  " << c << endl;

}
