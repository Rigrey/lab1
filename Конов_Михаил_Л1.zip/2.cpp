#include <iostream>
#include <cmath>

using namespace std;

char k;

int main(){
    cout << "Vvedite simvol: ";
    cin >> k;
    cout << "1" << k << "13" << k << "49" << endl;

}
