#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int a, b, c;
    cout << "Vvedite pervoe chislo: " << endl;
    cin >> a;
    cout << "Vvedite vtoroe chislo: " << endl;
    cin >> b;
    cout << "Vvedite tretie chislo: " << endl;
    cin >> c;
    cout << a << "  " << b << "  " << c << endl;

}
