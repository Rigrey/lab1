#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    float x1, x2, y1, y2, r;
    cout << "Vvedite koordinati pervoy tochki cherez probel: " << endl;
    cin >> x1 >> y1;
    cout << "Vvedite koordinati vtoroy tochki cherez probel: " << endl;
    cin >> x2 >> y2;
    r = sqrt (pow(y1 - y2, 2) + pow(x1 - x2, 2));
    cout << "Rasstoyanie mezhdu tochkami ravno: " << r;
    return 0;
}
