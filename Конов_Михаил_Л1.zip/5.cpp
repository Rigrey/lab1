#include <iostream>
#include <cmath>

using namespace std;

int main(){
float b, v;
cout << "Vvedite obyem i massu cherez probel: " << endl;
cin >> v >> b;
cout << "Plotnost tela " << b / v<< endl;

}

