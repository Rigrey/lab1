#include <iostream>
#include <string>

using namespace std;

int main(){
string name;
cout << "Vvedite imya studenta: " << endl;
cin >> name;
cout << "Hello, " << name << "! " << "My name is C++" << endl;



}

