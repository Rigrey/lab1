#include <iostream>
#include <cmath>

using namespace std;

int main(){
    float a, b, h, d1, d2;
    cout << "Vvedite vysotu i osnovaniya cherez probel" << endl;
    cin >> h >> a >> b;
    d1 = sqrt(pow((a-b)/2, 2) + (pow(h, 2)));
    d2 = d1;
    cout << "Perimetr trapecii raven: " << a + b + d1 + d2;





}
