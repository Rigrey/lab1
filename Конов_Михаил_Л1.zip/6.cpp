#include <iostream>
#include <cmath>

using namespace std;

int main(){
float a, b;
cout << "Vvedite a i b cherez probel, a ne ravnoe nulyu: " << endl;
cin >> a >> b;
cout << "Reshenie uravneniya: " << -1 * (b / a) << endl;

}

