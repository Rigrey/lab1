#include <iostream>
#include <cmath>

using namespace std;


int main(){

    cout << "1 " << "13" << " 49" << endl;

}
