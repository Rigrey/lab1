#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float r;
    cout << "Vvedite radius okruzhnosti: " << endl;
    cin >> r;
    cout << "Diametr okruzhnosti raven: " << 2 * r << endl;
}
