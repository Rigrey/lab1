#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float b;
    cout << "Vvedite storonu kuba: " << endl;
    cin >> b;
    cout << "Obyem kuba raven: " << pow(b, 3) << "Ploschad bokovoi poverhnosti ravna: " << 6 * pow(b, 2) << endl;
    return 0;
}
