#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float x;
    cout << "Vvedite x: ";
    cin >> x;
    cout << 3 * pow(x, 3) + 4 * pow(x, 2) - 11 * x + 1 << endl;
}
