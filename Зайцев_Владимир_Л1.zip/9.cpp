#include <iostream>

using namespace std;

int main()
{
    double a,v,s;
    cin>> a;
    v=a*a*a;
    s=4*a*a;
    cout<<v<<endl;
    cout<<s<<endl;
    return 0;
}
