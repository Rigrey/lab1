#include <iostream>

using namespace std;

int main()
{
    double a,p;
    cin>>a;
    p=4*a;
    cout<<p<<endl;
    return 0;
}
