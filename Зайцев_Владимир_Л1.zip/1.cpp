#include <iostream>

using namespace std;

int main()
{
    int a=1, b=13, c=49;
    cout<< a << " " << b << " " << c;
    return 0;
}
