#include <iostream>

using namespace std;

int main()
{
    double r,d;
    cin>> r;
    d=2*r;
    cout<<d<<endl;
    return 0;
}
