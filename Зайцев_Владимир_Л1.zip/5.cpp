#include <iostream>

using namespace std;

int main()
{
    double m,v,p;
    cin>> m>> v;
    p=m/v;
    cout<<p;
    return 0;
}
