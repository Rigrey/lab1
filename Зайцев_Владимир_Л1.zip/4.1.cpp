#include <iostream>

using namespace std;

int main()
{
    double a,x;
    cin>>a;
    x= 12*a*a+7*a-12;
    cout<<x<<endl;

    return 0;
}
