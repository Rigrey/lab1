#include <iostream>
#include<cmath>

using namespace std;

int main()
{
    double a,b,c,P,m,h;
    cin>>a>>b>>h;
    m=(a-b)/2;
    c=sqrt(m*m+h*h);
    P=a+b+2*c;
    cout<<P<<endl;
    return 0;
}
