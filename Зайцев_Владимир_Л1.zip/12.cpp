#include <iostream>

using namespace std;

int main()
{
    string n;
    cin>>n;
    cout<< "Hello,"<< n << "!" << "My name is C++";
    return 0;
}
