#include <iostream>

using namespace std;

int main()
{
    int a=1, b=13, c=49;
    char x;
    cin>>x;
    cout << a << x << b << x << c;
    return 0;
}
