#include <iostream>

using namespace std;

int main()
{
    double a,b,x;
    cin>>a>>b;
    x=-b/a;
    cout<<x<<endl;
    return 0;
}
