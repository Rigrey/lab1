#include <iostream>

using namespace std;

int main()
{
    double x,y;
    cin>> x;
    y=3*x*x*x+4*x*x-11*x+1;
    cout<<y<<endl;
    return 0;
}
